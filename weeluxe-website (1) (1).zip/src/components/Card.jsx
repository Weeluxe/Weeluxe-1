import React from "react";

export function Card({ item }) {
  return (
    <div className="shadow-lg rounded-lg p-4 bg-white hover:scale-105 transition">
      <img src={`/product-${item}.jpg`} alt={`Product ${item}`} className="w-full h-60 object-cover rounded-md" />
      <h4 className="text-xl font-medium mt-4">Product {item}</h4>
      <p className="text-gray-600 mt-2">High-quality fashion item.</p>
      <button className="mt-4 w-full bg-black text-white py-2 rounded-full">Buy Now</button>
    </div>
  );
}
