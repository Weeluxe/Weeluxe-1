import React from "react";

export function Button({ children }) {
  return (
    <button className="text-white bg-black px-6 py-2 text-lg rounded-full hover:opacity-90 transition">
      {children}
    </button>
  );
}
